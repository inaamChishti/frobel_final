<div>

    <?php if(Session::has($alert)): ?>
            <?php if($alert): ?>
                <div class="alert <?php echo e($alert); ?> alert-dismissible fade show" role="alert">
                    <strong><?php echo e($alertName); ?>!</strong> <?php echo e($sessionMessage); ?>.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
    <?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\frobel_final_updated\frobel_final\resources\views/components/flash-message.blade.php ENDPATH**/ ?>