<?php $__env->startSection('styles'); ?>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/4.0.1/min/dropzone.min.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/4.2.0/min/dropzone.min.js"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid flex-grow-1 container-p-y">

    <h4 class="font-weight-bold py-3 mb-4">
      <span class="text-muted font-weight-light">Student Tests /</span> Add Record
    </h4>


    <!-- alerts -->

    <?php if(Session::has('alert-success')): ?>
    <div class="alert alert-success alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Success!</strong> <?php echo e(Session::get('alert-success')); ?>.
    </div>
    <?php endif; ?>


    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>


    <!-- DataTable within card -->
    <div class="card">
        <div class="card-header bg-primary text-white"><h5><b>Add Student Test</b></h5></div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.student.test.manual.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="">Family Id</label>
                    <input type="number" name="family_id" id="family_id" value="<?php echo e(old('family_id')); ?>" class="form-control" placeholder="1">
                </div>
                <div class="form-group">
                    <label for="">Student Name</label>
                    <select name="student_name" id="student_name" class="form-control">
                        <option value="" disabled selected>Choose Option</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="">Subjects</label>
                    <select name="subject" id="subject" class="form-control">
                        <option value="" disabled selected>Choose Option</option>
                        <?php if(count($subjects) > 0): ?>
                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($subject->name); ?>"><?php echo e($subject->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="">Book</label>
                    <input type="text" name="book" value="<?php echo e(old('book')); ?>" class="form-control" placeholder="Book name">
                </div>
                <div class="form-group">
                    <label for="">Test No</label>
                    <input type="text" name="test_no" value="<?php echo e(old('test_no')); ?>" class="form-control" placeholder="Test No">
                </div>
                <div class="form-group">
                    <label for="">Attempt</label>
                    <input type="text" name="attempt" value="<?php echo e(old('attempt')); ?>" class="form-control" placeholder="Attempt">
                </div>
                <div class="form-group">
                    <label for="">Date</label>
                    <input type="date" name="date" value="<?php echo e(old('date')); ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label for="">Percentage</label>
                    <input type="text" name="percentage" value="<?php echo e(old('percentage')); ?>" class="form-control" placeholder="10">
                </div>
                <div class="form-group">
                    <label for="">Status</label>
                    <input type="text" name="status" value="<?php echo e(old('status')); ?>" class="form-control" placeholder="status">
                </div>
                <div class="form-group">
                    <label for="">Tutor</label>
                    <input type="text" name="tutor" value="<?php echo e(old('tutor')); ?>" class="form-control" placeholder="Tutor name">
                </div>

                <div class="form-group">
                    <label for="">Updated By</label>
                    <input type="text" name="updated_by" value="<?php echo e(old('updated_by')); ?>" class="form-control" placeholder="Updated By">
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-info">Submit</button>
                </div>
            </form>
        </div>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#family_id').on('focusout', function() {
            var family_id = this.value;
            $('#student_name').empty('');
            $('#student_name').append('<option value="" disabled selected>Choose Option</option>');

            $.ajax({
                url: "<?php echo e(route('get-family-students', '')); ?>" + '/' + family_id,
                method: "Post",
                data: { family_id },
                success: function (data) {
                    $.each(data, function (i, item) {
                        $('#student_name').append($('<option>', {
                            value: item.name,
                            text : item.name
                        }));
                    });
                },
                error: function (error) {
                    swal("Erorr!", "Something went wrong, Please refresh the webpage and try again, if still problem persists contact with administrator", "error");
                }
            });
        });
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\frobel_final_updated\frobel_final\resources\views/auth/student/test/manual/create.blade.php ENDPATH**/ ?>