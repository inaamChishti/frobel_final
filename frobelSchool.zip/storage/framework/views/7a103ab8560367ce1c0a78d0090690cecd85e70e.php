<?php $__env->startSection('styles'); ?>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/4.0.1/min/dropzone.min.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/4.2.0/min/dropzone.min.js"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid flex-grow-1 container-p-y">

    <h4 class="font-weight-bold py-3 mb-4">
      <span class="text-muted font-weight-light">Student Tests /</span> Add Records
    </h4>


    <!-- alerts -->

    <?php if(Session::has('alert-success')): ?>
    <div class="alert alert-success alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Success!</strong> <?php echo e(Session::get('alert-success')); ?>.
    </div>
    <?php endif; ?>


    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>


    <!-- DataTable within card -->
    <div class="card">
        <h5 class="card-header float-right">Upload sheet</h5>


     <div class="container-fluid mt-3">
        <form action="<?php echo e(route('admin.student-test.import')); ?>" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div class="mb-3">
              <label for="file" class="form-label">Choose Excel</label>
              <input type="file" name="file" class="form-control">
              <small class="text-danger">Only these format will be accepted. (xls, csv, xlsx)</small> <br>
              <button type="submit" class="btn btn-primary mt-2">Submit</button>
            </div>
        </form>

        <div>
            <form method="post" action="<?php echo e(route('admin.download.sample.sheet')); ?>">
                <?php echo csrf_field(); ?>
                <button class="btn btn-info mb-2" style="float: right">Download Template Sheet</button>
            </form>
        </div>

     </div>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\frobel_final_updated\frobel_final\resources\views/auth/student/test/create.blade.php ENDPATH**/ ?>