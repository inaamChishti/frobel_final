<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/libs/datatables/datatables.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid flex-grow-1 container-p-y">

    <div class="media align-items-center py-3 mb-3">
    <img src="<?php echo e(asset('img/avatars/user-default.png')); ?>" alt="" class="d-block ui-w-100 rounded-circle">
      <div class="media-body ml-4">
      <h4 class="font-weight-bold mb-0"><?php echo e(@$student->name); ?> <span class="text-muted font-weight-normal"><?php echo e($student->surname); ?></span></h4>
      <div class="text-muted mb-2">ID: <?php echo e(@$student->studentid); ?></div>
      <a href="<?php echo e(route('admin.admission.edit', @$student->studentid)); ?>" class="btn btn-primary btn-sm">Edit</a>&nbsp;
      <a href="<?php echo e(route('admin.admission.show', @$student->studentid)); ?>" class="btn btn-default btn-sm">Profile</a>&nbsp;
      <a href="<?php echo e(route('admin.admission.index')); ?>" class="btn btn-warning btn-sm">Back</a>&nbsp;
        
      </div>
    </div>



    <div class="card mb-4">
        <div class="card-body">
            <h5 class="card-title">Family Details</h5>
          <table class="table user-view-table m-0">
            <tbody>
                <tr>
                    <td>Student Name:</td>
                    <td><?php echo e(@$student->studentname); ?> <?php echo e(@$student->studentsur); ?></td>
                  </tr>

              <tr>
                  <td>Family Id:</td>
                  <td><?php echo e(@$admission->familyno); ?></td>
                </tr>
              
              <tr>
                <td>Family Status:</td>
                <td> <?php if(@$admission->familystatus == 'Active'): ?> <span class="badge badge-outline-success"> Active </span>&nbsp <?php else: ?> <span class="badge badge-outline-danger"> De-Active <?php endif; ?> </td>
              </tr>
              <tr>
                <td>Joining Date:</td>
              <td>
                <?php if(!empty($admission->joiningdate && preg_match('/\d/', $student->joiningdate))): ?>
                <?php echo e(\Carbon\Carbon::parse($admission->joiningdate)->format('d-F-Y')); ?>

            <?php endif; ?>
                
            </td>
              </tr>
              <tr>
                <td>Fee Detail:</td>
                <td><?php echo e(@$admission->feedetail); ?></td>
              </tr>
              
              
              
              <tr>
                <td>Comment:</td>
                <td><?php echo e(@$admission->add_comment); ?></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>


    <!--  Guardian Details -->
      <div class="card mb-4">
        <div class="card-body">
            <h5 class="card-title">Guardian Details</h5>
          <table class="table user-view-table m-0">
            <tbody>
              <tr>
                  <td>Name:</td>
                  <td><?php echo e(@$guardianData->guardianname); ?></td>
                </tr>
              <tr>
                <td>Address:</td>
                <td><?php echo e(@$guardianData->guardianaddress); ?></td>
              </tr>
              <tr>
                <td>Mobile:</td>
              <td><?php echo e(@$guardianData->guardianmob); ?></td>
              </tr>
              
              

                
              </tr>

            </tbody>
          </table>
        </div>
      </div>


    <!-- Kin Details -->
    <div class="card mb-4">
        <div class="card-body">
            <h5 class="card-title">Kin Details</h5>
          <table class="table user-view-table m-0">
            <tbody>
              <tr>
                  <td>Name:</td>
                  <td><?php echo e(@$kinDetails->kinname); ?></td>
                </tr>
              <tr>
                <td>Address:</td>
                <td><?php echo e(@$kinDetails->kinaddress); ?></td>
              </tr>
              <tr>
                <td>Mobile:</td>
              <td><?php echo e(@$kinDetails->kinmob); ?></td>
              </tr>
              

            </tbody>
          </table>
        </div>
      </div>
      

            


    <div class="card">
        <div class="card-body">
          <h5 class="card-title">Total Students</h5>
          <hr class="border-light m-0">
          <div class="table-responsive">
            <table id="example" class="table card-table m-0">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Surname</th>
                        <th>Date of Birth</th>
                        <th>Gender</th>
                        <th>Years in School</th>
                        <th>Hours</th>
                      </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = @$total_students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(@$student->studentname); ?></td>
                            <td><?php echo e(@$student->studentsur); ?></td>
                            <td>
                                <?php if(!empty($student->studentdob && preg_match('/\d/', $student->studentdob))): ?>
                                    <?php echo e(\Carbon\Carbon::parse($student->studentdob)->format('d-F-Y')); ?>

                                <?php endif; ?>
                                
                            </td>
                            <td><?php echo e(@$student->studentgender); ?></td>
                            <td><?php echo e(@$student->studentyearinschool); ?></td>
                            <td><?php echo e(@$student->studenthours); ?></td>
                         </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        </div>
        </div>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('assets/libs/datatables/datatables.js')); ?>"></script>
<script>
    $('#example').DataTable();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\frobel_final_updated\frobel_final\resources\views/auth/admission/show.blade.php ENDPATH**/ ?>