<!-- upload.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Upload Excel</title>
</head>
<body>
    <form action="<?php echo e(route('upload')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="file" name="excel_file">
        <button type="submit">Submit</button>
    </form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\frobel_final_updated\frobel_final\resources\views/testing/index.blade.php ENDPATH**/ ?>