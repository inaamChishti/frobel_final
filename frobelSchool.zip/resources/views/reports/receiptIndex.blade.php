<iframe src="{{ $pdfDataUri }}" style="width:100%; height:100%;"></iframe>
