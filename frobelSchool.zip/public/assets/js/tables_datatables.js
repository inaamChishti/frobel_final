$(function() {
  $('.datatables-demo').dataTable();
});
